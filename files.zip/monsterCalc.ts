// ui/src/views/bestiary/monsterCalc.ts
//
// ── Monster Statblock Calculation Utilities ───────────────────────────────────
//
// All derived-stat logic lives here and NOWHERE ELSE.
// Components import these functions; they never inline the math themselves.
//
// Rules:
//   - Pure functions only (no side effects, no imports from React or atlas)
//   - Every function is independently unit-testable
//   - Backward-compatible: all inputs are optional / have sensible defaults
// ─────────────────────────────────────────────────────────────────────────────

// ── Ability score keys ────────────────────────────────────────────────────────

export type AbilityKey = 'str' | 'dex' | 'con' | 'int' | 'wis' | 'cha';

export const ABILITY_KEYS: AbilityKey[] = ['str', 'dex', 'con', 'int', 'wis', 'cha'];

export const ABILITY_LABELS: Record<AbilityKey, string> = {
  str: 'STR', dex: 'DEX', con: 'CON',
  int: 'INT', wis: 'WIS', cha: 'CHA',
};

// ── CR → XP table (5e SRD) ───────────────────────────────────────────────────

const CR_XP: Record<string, number> = {
  '0': 10,   '1/8': 25,  '1/4': 50,  '1/2': 100,
  '1': 200,  '2': 450,   '3': 700,   '4': 1100,
  '5': 1800, '6': 2300,  '7': 2900,  '8': 3900,
  '9': 5000, '10': 5900, '11': 7200, '12': 8400,
  '13': 10000,'14': 11500,'15': 13000,'16': 15000,
  '17': 18000,'18': 20000,'19': 22000,'20': 25000,
  '21': 33000,'22': 41000,'23': 50000,'24': 62000,
  '25': 75000,'26': 90000,'27': 105000,'28': 120000,
  '29': 135000,'30': 155000,
};

// ── CR → Proficiency Bonus table (5e SRD) ─────────────────────────────────────
//
// CR  0–4  → +2
// CR  5–8  → +3
// CR  9–12 → +4
// CR 13–16 → +5
// CR 17–20 → +6
// CR 21–24 → +7
// CR 25–28 → +8
// CR 29–30 → +9

const CR_PB: Record<string, number> = {
  '0': 2, '1/8': 2, '1/4': 2, '1/2': 2,
  '1': 2, '2': 2, '3': 2, '4': 2,
  '5': 3, '6': 3, '7': 3, '8': 3,
  '9': 4, '10': 4, '11': 4, '12': 4,
  '13': 5, '14': 5, '15': 5, '16': 5,
  '17': 6, '18': 6, '19': 6, '20': 6,
  '21': 7, '22': 7, '23': 7, '24': 7,
  '25': 8, '26': 8, '27': 8, '28': 8,
  '29': 9, '30': 9,
};

// ── Core derivation functions ─────────────────────────────────────────────────

/**
 * Derive proficiency bonus from challenge rating string.
 * Returns the SRD value, or 2 as a safe fallback for unknown CRs.
 */
export function proficiencyFromCR(cr: string): number {
  return CR_PB[cr] ?? 2;
}

/**
 * Derive XP award from challenge rating string.
 * Returns 0 for unknown CRs.
 */
export function xpFromCR(cr: string): number {
  return CR_XP[cr] ?? 0;
}

/**
 * Compute the ability score modifier (floor((score - 10) / 2)).
 * Returns an integer; format with formatMod() for display.
 */
export function abilityModifier(score: number): number {
  return Math.floor((score - 10) / 2);
}

/**
 * Format a signed modifier for display: "+2", "-1", "+0".
 */
export function formatMod(mod: number): string {
  return mod >= 0 ? `+${mod}` : `${mod}`;
}

/**
 * Convenience: get a formatted modifier string directly from an ability score.
 */
export function formatAbilityMod(score: number): string {
  return formatMod(abilityModifier(score));
}

// ── Saving throw calculation ───────────────────────────────────────────────────

/**
 * Compute a saving throw total.
 *
 * @param abilityScore  - The raw ability score (e.g. STR 16)
 * @param proficient    - Whether the creature has saving throw proficiency
 * @param profBonus     - Proficiency bonus (from proficiencyFromCR or manual)
 * @param override      - If provided, bypass calculation and use this value
 */
export function calcSavingThrow(
  abilityScore: number,
  proficient:   boolean,
  profBonus:    number,
  override?:    number,
): number {
  if (override !== undefined) return override;
  const mod = abilityModifier(abilityScore);
  return proficient ? mod + profBonus : mod;
}

/**
 * Saving throw configuration for the form — one entry per ability.
 * Stored as form state; serialised to the DB `saving_throws` column
 * as computed final values (Partial<AbilityScores> of numbers).
 */
export interface SaveThrowConfig {
  proficient: boolean;
  /** When set, overrides the computed value entirely. */
  override?: number;
}

export type SaveThrowConfigs = Partial<Record<AbilityKey, SaveThrowConfig>>;

/**
 * Compute all saving throw final values from config + ability scores.
 * Returns only entries where the creature has proficiency OR an override.
 * Output is ready to JSON.stringify into the `saving_throws` DB column.
 */
export function computeSavingThrows(
  abilityScores: Record<AbilityKey, number>,
  configs:       SaveThrowConfigs,
  profBonus:     number,
): Partial<Record<AbilityKey, number>> {
  const result: Partial<Record<AbilityKey, number>> = {};
  for (const key of ABILITY_KEYS) {
    const cfg = configs[key];
    if (!cfg) continue;
    if (!cfg.proficient && cfg.override === undefined) continue;
    result[key] = calcSavingThrow(abilityScores[key], cfg.proficient, profBonus, cfg.override);
  }
  return result;
}

/**
 * Reconstruct SaveThrowConfigs from stored DB values.
 * Since the DB only stores final numbers (not the proficient flag),
 * we infer proficiency by checking whether the stored value equals
 * the expected proficient value. This is a best-effort reconstruction
 * for existing records; new records store configs directly in form state.
 */
export function inferSaveConfigs(
  storedThrows:  Partial<Record<AbilityKey, number>>,
  abilityScores: Record<AbilityKey, number>,
  profBonus:     number,
): SaveThrowConfigs {
  const configs: SaveThrowConfigs = {};
  for (const key of ABILITY_KEYS) {
    const stored = storedThrows[key];
    if (stored === undefined) continue;
    const modOnly  = abilityModifier(abilityScores[key]);
    const withProf = modOnly + profBonus;
    // If stored value == modifier + profBonus → assume proficient, no override
    if (stored === withProf) {
      configs[key] = { proficient: true };
    } else {
      // Otherwise treat as manual override (proficient flag doesn't matter for display)
      configs[key] = { proficient: false, override: stored };
    }
  }
  return configs;
}

// ── Attack bonus calculation ───────────────────────────────────────────────────

/**
 * Compute an attack bonus for an action.
 *
 * @param abilityScore - Ability score used for the attack (STR or DEX typically)
 * @param proficient   - Whether proficiency applies to this attack
 * @param profBonus    - Proficiency bonus
 * @param override     - Manual override; bypasses calculation when set
 */
export function calcAttackBonus(
  abilityScore: number,
  proficient:   boolean,
  profBonus:    number,
  override?:    number,
): number {
  if (override !== undefined) return override;
  const mod = abilityModifier(abilityScore);
  return proficient ? mod + profBonus : mod;
}

// ── Damage bonus calculation ───────────────────────────────────────────────────

/**
 * Compute the bonus portion of a damage roll (not the dice part).
 *
 * @param abilityScore - Ability score driving the damage bonus
 * @param override     - Manual override
 */
export function calcDamageBonus(
  abilityScore: number,
  override?:    number,
): number {
  if (override !== undefined) return override;
  return abilityModifier(abilityScore);
}

// ── Spell save DC ─────────────────────────────────────────────────────────────

/**
 * Compute spell save DC: 8 + proficiency bonus + spellcasting ability modifier.
 *
 * @param spellcastingAbility - Ability score used for spellcasting (INT/WIS/CHA)
 * @param profBonus           - Proficiency bonus
 * @param override            - Manual override
 */
export function calcSpellSaveDC(
  spellcastingAbility: number,
  profBonus:           number,
  override?:           number,
): number {
  if (override !== undefined) return override;
  return 8 + profBonus + abilityModifier(spellcastingAbility);
}

/**
 * Compute spell attack bonus: proficiency bonus + spellcasting ability modifier.
 */
export function calcSpellAttackBonus(
  spellcastingAbility: number,
  profBonus:           number,
  override?:           number,
): number {
  if (override !== undefined) return override;
  return profBonus + abilityModifier(spellcastingAbility);
}

// ── Extended action type ───────────────────────────────────────────────────────
//
// Extends the existing ActionRow (stored as JSON in the DB) with optional
// automation fields. All new fields are optional so existing stored JSON
// remains valid without migration.

export interface ActionCalcFields {
  /** Which ability score drives the attack/damage bonus. Default: 'str' */
  abilityKey?: AbilityKey;
  /** Whether proficiency applies to the attack bonus. Default: true */
  proficient?: boolean;
  /**
   * When set, overrides the calculated attackBonus entirely.
   * This is already present as `attackBonus` in the existing ActionRow —
   * we treat the existing field as the override when present.
   */
  attackBonusOverride?: number;
  /**
   * When set, overrides the calculated damage bonus portion.
   * The dice string (e.g. "2d6") stays in `damage`; this overrides the +N part.
   */
  damageBonusOverride?: number;
}

// ── Passive Perception ────────────────────────────────────────────────────────

/**
 * Compute passive Perception: 10 + perception skill bonus.
 * If the creature has Perception proficiency, that's already in skillBonus.
 */
export function calcPassivePerception(
  wisScore:     number,
  perceptionBonus?: number,
): number {
  if (perceptionBonus !== undefined) return 10 + perceptionBonus;
  return 10 + abilityModifier(wisScore);
}

// ── Spellcasting ability options ──────────────────────────────────────────────

export const SPELLCASTING_ABILITIES: AbilityKey[] = ['int', 'wis', 'cha'];

export const ABILITY_FULL_NAMES: Record<AbilityKey, string> = {
  str: 'Strength', dex: 'Dexterity', con: 'Constitution',
  int: 'Intelligence', wis: 'Wisdom', cha: 'Charisma',
};
